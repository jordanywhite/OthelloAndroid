
package edu.up.cs301.othello;

import edu.up.cs301.game.infoMsg.GameState;

/**
 * Contains the state of an Othello game. Sent by the game when a player wants
 * to enquire about the state of the game. Contains the board, pieces, and
 * player turn.
 * 
 * @author Jordan White
 * @version 11/02/2013
 */
public class OthelloState extends GameState
{
    private static final long serialVersionUID = 7552321013488624386L;

    // /////////////////////////////////////////////////
    // ************** instance variables ************
    // /////////////////////////////////////////////////

    // Contains the actual board and every disk on it
    private CellState[][] board;

    // Defines which player's turn it is (black = 0, white = 1)
    private int playerTurn;

    private int whiteScore;
    private int blackScore;

    /**
     * Constructor for objects of class OthelloState
     */
    public OthelloState()
    {
        // Initialize the state to be a brand new game
        board = new CellState[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j] = CellState.EMPTY;
            }
        }

        // Starting pieces
        setDisk(3, 3, CellState.WHITE);
        setDisk(4, 4, CellState.WHITE);
        setDisk(3, 4, CellState.BLACK);
        setDisk(4, 3, CellState.BLACK);

        // make it black's turn
        playerTurn = 0;

        // Starting score of 2 for each player
        whiteScore = 2;
        blackScore = 2;

    }// constructor

    /**
     * Copy constructor for class OthelloState
     * 
     * @param original the OthelloState object that we want to clone
     */
    public OthelloState(OthelloState original)
    {
        // create a new 3x3 array, and copy the values from
        // the original
        board = new CellState[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j] = original.board[i][j];
            }
        }

        // copy the player-to-move information
        playerTurn = original.playerTurn;

        // Get the scores from the board
        setScores();
    }

    /**
     * Checks a move to see if it captures pieces in at least one direction
     * 
     * @param row the row
     * @param col the column
     * @return true if move is legal, false if illegal
     */
    public boolean isLegalMove(int row, int col) {

        // player represents the color the player whose move it is
        CellState player = (playerTurn == 0 ? CellState.BLACK : CellState.WHITE);
        CellState enemy = (playerTurn == 0 ? CellState.WHITE : CellState.BLACK);

        // Ensures no null pointer nonsense
        if (getDisk(row, col) == null) {
            return false;
        }

        // Cycles through all cells surrounding the desired move
        for (int i = -1; i < 2; i++) {
            for (int j = -1; j < 2; j++) {

                // Disk being "looked at" to check if it fits the sequence for a
                // move
                CellState checkDisk = getDisk(row + i, col + j);

                // Off the board, check next sequence
                if (checkDisk == null)
                    continue;

                // Not next to an enemy piece, or looking at the move location,
                // check next sequence
                if (!checkDisk.equals(enemy) || (i == 0 && j == 0)) {
                    continue;
                }

                // Linear distance from the desired move location
                int count = 2;

                // Moves to the next piece in the current sequence for a
                // potential move
                checkDisk = getDisk(row + i * count, col + j * count);

                // Go until the current sequence runs off the board, in which
                // case continue to next sequence
                while (checkDisk != null) {

                    // Sequence completed, is a legal move
                    if (checkDisk.equals(player)) return true;

                    // Sequence interupted, move to next sequence
                    if (checkDisk.equals(CellState.EMPTY)) break;

                    // This piece was an enemy piece so continue to next piece
                    // in the sequence
                    count++;
                    checkDisk = getDisk(row + i * count, col + j * count);
                }
            }
        }

        // Checked every potential direction where the move could be legal and
        // found no captures. Not a legal move.
        return false;
    }

    /**
     * Runs through the board and finds all legal moves for the player whose
     * turn it is
     * 
     * @return a boolean array where each true identifies a legal move for the
     *         player on the board
     */
    public boolean[][] getLegalMoves() {
        boolean[][] legalMoves = new boolean[8][8];

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (isLegalMove(i, j)) {
                    legalMoves[i][j] = true;
                } else {
                    legalMoves[i][j] = false;
                }
            }
        }

        return legalMoves;
    }

    /**
     * Counts every piece on the board and updates the black and white scores
     * accordingly
     */
    public void setScores() {
        // Resets score for each count
        whiteScore = 0;
        blackScore = 0;

        // Cycles through board and gives each player 1 point for each piece
        // they own
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (board[i][j].equals(CellState.WHITE)) {
                    whiteScore++;
                } else if (board[i][j].equals(CellState.BLACK)) {
                    blackScore++;
                }
            }
        }
    }

    /**
     * Find out which piece is in a cell
     * 
     * @param row the row
     * @param col the column
     * @return the piece at the given square; EMPTY if no piece there; null if
     *         it is an illegal square
     */
    public CellState getDisk(int row, int col) {
        // if we're out of bounds or something is horribly wrong, we return null
        if (board == null || row < 0 || col < 0)
            return null;
        if (row >= board.length || col >= board[row].length)
            return null;

        // return the CellState of the requested position
        return board[row][col];
    }

    /**
     * Sets a piece on a cell
     * 
     * @param row the row being queried
     * @param col the column being queried
     * @param piece the piece to place
     */
    public void setDisk(int row, int col, CellState piece) {
        // if we're out of bounds or anything, return and do nothing
        if (board == null || row < 0 || col < 0)
            return;
        if (row >= board.length || col >= board[row].length)
            return;

        // Places the piece
        board[row][col] = piece;
    }

    /**
     * Tells whose move it is.
     * 
     * @return the index (0 or 1) of the player whose move it is.
     */
    public int getTurn() {
        return playerTurn;
    }

    /**
     * set whose move it is
     * 
     * @param playerTurn the player we want to accept the next move from
     */
    public void setTurn(int playerNum) {
        playerTurn = playerNum;
    }

    /**
     * @return Number of white pieces on the board
     */
    public int getWhiteScore() {
        return whiteScore;
    }

    /**
     * @return Number of black pieces on the board
     */
    public int getBlackScore() {
        return blackScore;
    }
}
