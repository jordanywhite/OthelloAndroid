package edu.up.cs301.othello;

import edu.up.cs301.game.Game;

/**
 * Interface which implements a OthelloGame
 * 
 * @author Stephen Robinson
 * @version November 2013
 */
public interface OthelloGame extends Game {
}
