package edu.up.cs301.othello;

import edu.up.cs301.game.GameComputerPlayer;
import edu.up.cs301.game.infoMsg.GameInfo;

/**
 * An abstract class which defines an Othello computer player.
 * 
 * @author Stephen Robinson
 * @version November 2013
 */

public abstract class OthelloComputerPlayer extends GameComputerPlayer implements OthelloPlayer {
	
	protected OthelloState state;
	
    /**
     * OthelloComputerPlayer constructor
     */
    public OthelloComputerPlayer(String name) {
        super(name);
    }//ctor
    
    /**
     * called when the state has been updated and it is this computer player's turn.
     */
    abstract protected void makeMove();
    	
    /**
     * Called when computer player receives information from the game.
     * 
     * @param info the info message from the game
     */
    @Override
    protected void receiveInfo(GameInfo info) {
    
    	//if this is a new updated state.
		if (info instanceof OthelloState){
			this.state = (OthelloState)info;

			//make sure it is our turn.
			if (this.state.getTurn() == this.playerNum){
				
		    	//sleep so it looks like the computer is deciding its move...
		    	sleep(1200);

		    	//tell the implementing class to make a move with the updated state.
		    	this.makeMove();
			}
		}
    	
    } //recieveInfo
}//class OthelloComputerPlayer
