package edu.up.cs301.othello;

import java.util.ArrayList;


/**
 * A computer ai player which analysis the game tree of possible worlds 
 * and selects the ideal branch.
 * 
 * @author Stephen Robinson
 * @version November 2013
 * 
 */
public class SmartOthelloComputerPlayer extends OthelloComputerPlayer
{
	/**
	 * constructor for SmartOthelloComputerPlayer
	 * 
	 * @param name the player name
	 */
	public SmartOthelloComputerPlayer(String name) {
		super(name);
	}//ctor

    /**
     * Called when the state has been updated and it is this computer player's turn.
     * 
     * TODO: make this player select a non-random move.
     */
    @Override
    protected void makeMove(){
        ArrayList<int[]> moves = new ArrayList<int[]>();

        // choose a random turn
        for (int i = 0; i < state.getLegalMoves().length; i++) {
            for (int j = 0; j < state.getLegalMoves()[i].length; j++) {

                if (state.isLegalMove(i, j)) {
                    int[] q = {i, j};
                    moves.add(q);
                }
            }
        }
        int choice = (int) (Math.random() * moves.size());
        
        if(moves.size() == 0) this.game.sendAction(new OthelloPassAction(this));
        
    	int x = moves.get(choice)[0];
    	int y = moves.get(choice)[1];
    	
    	this.game.sendAction(new OthelloMoveAction(this, x, y));
    } //makeMove

}
